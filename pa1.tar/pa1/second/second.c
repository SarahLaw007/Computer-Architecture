/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   second.c
 * Author: slaw
 *
 * Created on February 8, 2019, 2:51 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
 *
 */

struct Node {
    int data;
    struct Node* next; // Pointer to next node in DLL
    struct Node* prev; // Pointer to previous node in DLL
};
//GLOBAL VARIABLE

struct Node* head;
struct Node*headNoDup;
int numNodes = 0;

void printLinkedList() {
  struct Node* temp = head;
  while(temp != NULL) {
    printf("%d ",temp->data);
    temp = temp->next;
  }
  printf("\n");

}

void printNOdupl(){
  struct Node* temp = head;
  int prev;
  int numPrinted = 0;
  int *allNum = (int *) malloc(sizeof(int) * numNodes);
  int index = 0;
  //printf("NO DUPLICATE PRINT: ");
  //fill array of unique numbers
  while(temp != NULL) {
    if(numPrinted==0){
      allNum[index] = temp->data;
      prev = temp->data;

    }else{
      if(prev == temp->data){
        temp = temp->next;
        continue;
      }else{
        allNum[index] = temp->data;
        prev = temp->data;
      }

    }
    temp = temp->next;
    numPrinted++;
    index++;

  }
  //printf("\n");

  int i;
  //printf("I HAVE THIS MANY TO PRINT %d\n", index);
  for(i=0;i<index;i++){
    if(i==index-1){
      printf("%d", allNum[i]);
    }else{
      printf("%d\t", allNum[i]);

    }
  }
  //free(temp);
  free(allNum);
}

void insert(int toInsert){
  struct Node* temp = head;
  struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
  newGuy-> data = toInsert;
  while(temp != NULL) {

    //LAST GUY
    if(temp->next == NULL){
      //before last GUY
      if(toInsert < temp->data){
        newGuy->next=temp;
        newGuy->prev = temp->prev;
        temp->prev->next = newGuy;
        temp->prev = newGuy;
        break;
      }
      //printf("LAST GUY!!!!");
      newGuy->prev = temp;
      temp->next = newGuy;

      break;

    }
    //MIDDLE GUY
    if(toInsert<=temp->data){
        newGuy->next=temp;
        temp->prev->next = newGuy;
        newGuy->prev = temp->prev;
        temp->prev = newGuy;
        //printf("MIDDLE INSERT before %d", temp->data);

        break;




    //printf("%d ",temp->data);
    }
    temp = temp->next;

  //printf("\n");


  }


}

void delete(int toDelete){
  struct Node* tmp = head;
  while(tmp != NULL) {
    //delete head
    if(toDelete==head->data){
      //printf("HEAD!!!");
      head = head->next;
      numNodes--;
      free(tmp);
      break;
    } else if(toDelete == tmp->data && tmp->next == NULL){
      tmp->prev->next = NULL;
      numNodes--;
      free(tmp);

      break;
    }else if(toDelete == tmp->data){
      tmp->prev -> next = tmp->next;
      tmp->next->prev=tmp->prev;
      numNodes--;
      free(tmp);

      break;
    }

    //delete MIDDLE

    //delete tail



    tmp = tmp->next;
  }


}


int main(int argc, char** argv) {

  FILE *toTest;
  toTest = fopen(argv[1], "r");

  //if does not exist
  if( toTest==NULL)  {
    printf("error");
    return 0;
    //NO FCLOSE OR ELSE IT WILL SEG FAULT  int numNodes = 0;

  }
  //if blank
  if (NULL != toTest) {
    fseek (toTest, 0, SEEK_END);
    int size = ftell(toTest);

    if (0 == size) {
        printf("0\n");
        fclose(toTest);
        return 0;
    }
  }


  fseek(toTest, 0, SEEK_SET);

  char operation;
  int number;

  //struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));


  while(fscanf(toTest,"%c\t%d\n",&operation,&number)!=EOF){
    // printf("LOW integer is %d", currentLow);
    //printf("SOMETHING");
  //  printf("%c\t%d\n", operation, number);
    if(operation == 'i'){
      //printf("INSERTING %d \n", number);
      //make node
      //if NO NODES set head
      if(numNodes==0){
        struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
        newGuy-> data = number;
        head = newGuy;

      //if there is a node make the data isn't the same as head in data

      }else{
        if(number<head->data ||number== head->data){
          struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
          newGuy-> data = number;
          newGuy->next=head;
          head->prev = newGuy;
          head = newGuy;



        }else{
            insert(number);

        }
      }




      //free(newGuy);
      numNodes++;

    }else{
      //printf("DELETING %d \n", number);
      //printLinkedList( );

      delete(number);
      //printLinkedList( );




    }
    //printLinkedList( );



  }
  //printLinkedList( );
  //printf("ANSWER!!!!!!!");
  if(numNodes==0){
    printf("0\n");
    fclose(toTest);
    return 0;
  }
  //printf("\n");
  printf("%d\n", numNodes);
  printNOdupl();

  //FREEE!!!!!!!
  struct Node* temp = head;
  //printf("Forward: ");
  while(temp != NULL) {
    //printf("%d ",temp->data);
    struct Node* toFreeNext = temp->next;
    free(temp);
    temp = toFreeNext;
  }

  //fclose(toTest);
  //free(newGuy);

  fclose(toTest);

  return (EXIT_SUCCESS);

}
