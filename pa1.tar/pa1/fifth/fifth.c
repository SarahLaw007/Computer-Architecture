/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   fifth.c
 * Author: slaw
 *
 * Created on February 8, 2019, 2:52 PM
 */

#include <stdio.h>
//#include <stdlib.h>

/*
 *
 */
int main(int argc, char** argv) {
/*
    if(argc < 2){
      printf("");
      return 0;

    }
    */
    int i;
    int j;
  //  char* answer = (char*) malloc ((argc) * sizeof(char));
    int index = 0;



    for (i = 1; i < argc; i ++){
      j = 0;
    //  printf(argv[i]);
    //  printf("\n");
      while(argv[i][j] != '\0'){
        //printf("Argument %d letter %d : %c\n", i,j,argv[i][j]);
        //check cases
        if(argv[i][j]=='A'||argv[i][j]=='a'||argv[i][j]=='E'||argv[i][j]=='e'||argv[i][j]=='I'||argv[i][j]=='i'||
        argv[i][j]=='O'||argv[i][j]=='o'||argv[i][j]=='U'||argv[i][j]=='u'){
          printf("%c", argv[i][j]);

          //answer[index] = argv[i][j];
          index++;
        }





        j++;
      }
    }
/*
  //  printf("ANSWER!~~~~~~ \n");
    for (i = 0; i < index; i++){
      printf("%c", answer[i]);


    }
    */
    printf("\n");
    //free(answer);




    return 0;
}
