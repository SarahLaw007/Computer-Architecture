/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   main.c
 * Author: slaw
 *
 * Created on February 5, 2019, 12:11 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#define BUF_SIZE 2048
/*
 *
 */
int main(int argc, char** argv) {
	FILE *toTest = fopen(argv[1], "r");
	int numNums;
	fscanf(toTest, "%d",&numNums );
	//read file into array
	int *allNum = (int *) malloc(sizeof(int) * numNums);

	int i;
	int numEven =0;
	int numOdd = 0;

    	for (i = 0; i < numNums; i++){
        	fscanf(toTest, "%d", &allNum[i]);
		int current = (int) allNum[i];
              	if(current%2==0){
                        //printf("EVEN");
                        numEven++;
                 } else{
                      	//printf("ODD");
                        numOdd++;
                }
   	}
	int *evenArray = (int *) malloc(sizeof(int) * numEven);
	int *oddArray = (int *) malloc(sizeof(int) * numOdd);
	int evenEntered = 0;
        int oddEntered = 0;



    for (i = 0; i < numNums; i++){
		int toInsert = allNum[i];
                if(toInsert % 2 == 0){
        //	printf("Number is EVEN: %d\n\n", allNum[i]);

                       evenArray[evenEntered] = toInsert;
                       evenEntered++;
                 }else{
 	//	printf("Number is ODD: %d\n\n", allNum[i]);

                       oddArray[oddEntered] = toInsert;
                       oddEntered++;

                 }
	}
	//BEGIN SORTING
	//SORT EVEN FIRST
	int ee;
	for(ee= 0; ee < numEven; ee++){
                int currentLow = evenArray[ee];
                int currentLowIndex = ee;
		int eee;
                for(eee=ee; eee < numEven; eee++){
                	if(currentLow > evenArray[eee]){
                            currentLow = evenArray[eee];
                            currentLowIndex = eee;
                        }
                }
                    //begin swap
                    if(currentLowIndex == ee){
                        continue;
                    }
                    else{
                       // printf("LOW integer is %d", currentLow);

                        int temp = (int) evenArray[ee];
                        evenArray[ee] = currentLow;
                        evenArray[currentLowIndex] = temp;

                    }
        }
	//SORT ODD
	int oo;
	for(oo= 0; oo < numOdd; oo++){
 		int currentHigh = oddArray[oo];
                int currentHighIndex = oo;
		int ooo;
	      for(ooo=oo; ooo < numOdd; ooo++){
	          if(currentHigh < oddArray[ooo]){
	              currentHigh = oddArray[ooo];
	              currentHighIndex = ooo;
	          }
	      }
                    //begin swap
                    //printf("%d%s", currentLow, "new Low");

                    if(currentHighIndex == oo){
                        continue;
                    }
                    else{
                       // printf("LOW integer is %d", currentLow);

                        int temp = (int) oddArray[oo];
                        oddArray[oo] = currentHigh;
                        oddArray[currentHighIndex] = temp;

                    }
                }



		//PRINT ANSWER
		int printE;
 		for(printE= 0; printE < numEven; printE++){
                    printf("%d%s", evenArray[printE], "\t");


                }

		int printO;
		for(printO= 0; printO < numOdd; printO++){
			if(printO == (numOdd - 1)){
			   // printf("%d%s", printO, "trigger");

			    printf("%d", oddArray[printO]);

			}
				else{
				    printf("%d%s", oddArray[printO], "\t");

				}
		}

		//free odd
		free(evenArray);
		free(oddArray);
		free(allNum);





		fclose(toTest);

    return (EXIT_SUCCESS);
}
