#include <stdio.h>
#include <stdlib.h>


struct Node
{
  int data;
  struct Node *left;
  struct Node *right;
};
int numNums = 0;
int leafNum = 0;
struct Node *root;
void insert(int toInsert, struct Node* parent){

    if(numNums == 0){
      struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
      newGuy->data = toInsert;
      root = newGuy;
      numNums++;
    }

    else if(toInsert > parent->data){
        if(parent->right == NULL){
          struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
          newGuy->data = toInsert;
            parent->right = newGuy;
            numNums++;
        }else{
          insert(toInsert, parent->right);

        }

      }else if (toInsert < parent->data){
        if(parent->left == NULL){
          struct Node* newGuy = (struct Node*)malloc(sizeof(struct Node));
          newGuy->data = toInsert;
            parent->left = newGuy;
            numNums++;
        }else{
          insert(toInsert, parent->left);

        }

      }
}

void printlist(struct Node *parent){

  if (parent != NULL)
  {
      printlist(parent->left);
      if(leafNum!=(numNums-1)){
        printf("%d\t", parent->data);
        leafNum++;

      }else{
        printf("%d", parent->data);


      }
      printlist(parent->right);
  }



/*

  if(parent->left == NULL){

    if(leafNum!=(numNums-1)){
      printf("%d\t", parent->data);
      leafNum++;

    }else{
      printf("%d", parent->data);


    }
    if(parent->right!=NULL){
        printlist(parent->right);
    }
  } else{
    printlist(parent->left);
    if(leafNum!=(numNums-1)){
      printf("%d\t", parent->data);
      leafNum++;

    }else{
      printf("%d", parent->data);
    }    printlist(parent->right);
  }
  */
}


void freeTree(struct Node* leaftoFree){
  if( leaftoFree != 0 ){
      //kill children
      freeTree(leaftoFree->left);
      freeTree(leaftoFree->right);
      //now kill current guy
      free( leaftoFree );
  }
}
int main(int argc, char** argv) {
//  printf("GOT HERE");

  FILE *toTest;
  toTest = fopen(argv[1], "r");

  //if does not exist
  if( toTest==NULL)  {
    printf("error");
    return 0;
    //NO FCLOSE OR ELSE IT WILL SEG FAULT  int numNodes = 0;

  }
  //if blank
  if (NULL != toTest) {
    fseek (toTest, 0, SEEK_END);
    int size = ftell(toTest);

    if (0 == size) {
        printf("0\n");
        fclose(toTest);
        return 0;
    }
  }


  fseek(toTest, 0, SEEK_SET);

  char operation;
  int number;
  while(fscanf(toTest,"%c\t%d\n",&operation,&number)!=EOF){
    insert(number, root);
  }
  printlist(root);
  freeTree(root);
  fclose(toTest);
  return (EXIT_SUCCESS);
}
