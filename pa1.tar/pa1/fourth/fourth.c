/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   fourth.c
 * Author: slaw
 *
 * Created on February 8, 2019, 2:52 PM
 */

#include <stdio.h>
#include <stdlib.h>
int m1NumCol;
int m1NumRow;
int m2NumRow;
int m2NumCol;
int main(int argc, char** argv) {
	int i, j;
	//int **m1;
	//int **m2;
	FILE *toTest = fopen(argv[1], "r");
	//int m1NumRow;
	//int m1NumCol;

	fscanf(toTest, "%d",&m1NumRow );
  //printf("Number of rows in matrix 1: %d\n\n", m1NumRow);
	fscanf(toTest, "%d",&m1NumCol );
  //printf("Number of columns in matrix 1: %d\n\n", m1NumCol );

//Create Matrix 1
  	//int *m1 = (int *)malloc(m1NumRow * m1NumCol * sizeof(int));
		// int *m1[m1NumRow];
		//int **m1 = (int **) malloc(m1NumRow *m1NumCol *sizeof(int ) );
		int **m1 = (int **)malloc(m1NumRow * sizeof(int *));
	     for (i=0; i<m1NumRow; i++)
	          m1[i] = (int *)malloc(m1NumCol * sizeof(int));





//Begin filling it

		for (i = 0; i <  m1NumRow; i++) {
			for (j = 0; j < m1NumCol; j++) {
				//printf("next Num position %d%d ", i, j);
				int current;
				fscanf(toTest, "%d",&current); // Or *(*(arr+i)+j) = ++count
				m1[i][j]= current;
			}
			//printf("\n");

		}
		//printf("MATRIX 1: \n");
		/*
		for (i = 0; i <  m1NumRow; i++) {
				for(j=0; j< m1NumCol; j++){
					printf("%d", m1[i][j] );
					printf(" ");
		//	m1[i][j] = current;
				}
				printf("\n");

		}

*/

		//printf("MATRIX ONE CREATED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!: n\n");

// BEGIN MAKING MATRIX 2

	//int m2NumRow;
	fscanf(toTest, "%d",&m2NumRow );
	//printf("Number of rows in matrix 2: %d\n\n", m2NumRow);
	//int m2NumCol;
	fscanf(toTest, "%d",&m2NumCol);
	//printf("Number of columns in matrix 2: %d\n\n", m2NumCol);
	if(m1NumCol != m2NumRow){
							printf("bad-matrices");
							for (int i = 0; i < m1NumRow; i++){
								int* currentIntPtr = m1[i];
								free(currentIntPtr);
							}
							free(m1);
							fclose(toTest);
							return (EXIT_SUCCESS);
	}

	//Create Matrix 2

	// int *m2[m2NumRow];
	int **m2 = (int **)malloc(m2NumRow * sizeof(int *));
		 for (i=0; i<m2NumRow; i++)
					m2[i] = (int *)malloc(m2NumCol * sizeof(int));


	//Begin filling it
	//printf("Malloced\n");
	for (i = 0; i <  m2NumRow; i++) {
		for (j = 0; j < m2NumCol; j++) {
			fscanf(toTest, "%d",&m2[i][j]); // Or *(*(arr+i)+j) = ++count
			//printf("%d, ", m2[i][j]);
		}
	}

	//printf("fscanfed\n");
	//Print
	//printf("MATRIX 2: \n");
/*
	for (i = 0; i <  m2NumRow; i++) {
			for(j=0; j< m2NumCol; j++){
				printf("%d", m2[i][j] );

				printf(" ");
	//	m1[i][j] = current;
			}
			printf("\n");

	}

*/
		//printf("MATRIX TWO CREATED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!: \n");
		//printf("m1NumCol %d", m1NumCol);
		//CHECK IF COMPATIBLEm2NumRow


			//Now multiply

			//make answer MATRIX
			//printf("HERE!");
			int answerRow = m1NumRow;
			int answerCol = m2NumCol;
			//printf("BEGIN MALLOC");

			int **answer = (int **)malloc(answerRow * sizeof(int *));
		     for (i=0; i<answerRow; i++){
		          answer[i] = (int *)malloc(answerCol * sizeof(int));
						}


			//printf("BEGIN FILLING");
			int k;
			int answerEntry = 0;
			for(i=0; i<m1NumRow; i++){
				for(j=0; j<m2NumCol; j++ ){
					for(k=0; k < m1NumCol; k++){
						int point1= m1[i][k];
						int point2 = m2[k][j];
						//printf("%d*%d+", point1, point2);

						answerEntry = answerEntry + (point1*point2);

					}
					//printf("=%d", answerEntry);
					answer[i][j]= answerEntry;
					answerEntry=0;
				}
			}
			//printf("BEGIN PRINT ANSWER");

			//int **m1 = (int **) malloc(sizeof(int *) * m1NumRow);


			for (i = 0; i <  answerRow; i++) {
					for(j=0; j< answerCol; j++){
						printf("%d\t", answer[i][j] );
						//printf("\t");
					}
					printf("\n");
			}

			//printf("BEGIN FREE answerRowANSWER");

/*
			for (i = 0; i <  answerRow; i++) {
				for(j=0; j< answerCol; j++){
					free(&answer[i][j]);
				}
			}
			*/
			for (int i = 0; i < answerRow; i++){
				int* currentIntPtr = answer[i];
				free(currentIntPtr);
			}
			free(answer);

			for (int i = 0; i < m1NumRow; i++){
				int* currentIntPtr = m1[i];
				free(currentIntPtr);
			}
			free(m1);


			for (int i = 0; i < m2NumRow; i++){
				int* currentIntPtr = m2[i];
				free(currentIntPtr);
			}
			free(m2);


/*
			for (i = 0; i <  m1NumRow; i++) {
				for(j=0; j< m1NumCol; j++){
					free(&m1[i][j]);
				}
			}
			free(m1);

			for (i = 0; i <  m2NumRow; i++) {
				for(j=0; j< m2NumCol; j++){
					free(&m1[i][j]);
				}
			}
			free(m2);
*/
			/*for (i=0; i<answerCol; i++) {
					// m1[i] = (int *)malloc(m1NumCol * sizeof(int));
					 free(answer[i]);
			}

			free(answer);

			printf("FREE ANSWER");

			for (i=0; i<m1NumCol; i++) {
	        // m1[i] = (int *)malloc(m1NumCol * sizeof(int));
					 free(m1[i]);
			}

			free(m1);

			for (i=0; i<m2NumCol; i++) {
					// m1[i] = (int *)malloc(m1NumCol * sizeof(int));
					 free(m2[i]);
			}

			free(m2);

			*/


			fclose(toTest);


    return (EXIT_SUCCESS);
}
