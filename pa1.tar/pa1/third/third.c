/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   third.c
 * Author: slaw
 *
 * Created on February 8, 2019, 2:52 PM
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <stdlib.h>

#define BUCKETSIZE 10000

int numCollisions = 0;
int numSuccessfulSearch =0;

struct hashElement {
   int data;
   int key;
   struct hashElement* next;
} ;


//hashElement dummyItem, item;
struct hashElement* hashArray[BUCKETSIZE];

int getHash(int key) {
  //printf("KEY BEFORE MODIFICATION %d \n", key);

  if(key % BUCKETSIZE<0){
    while(key<=-20000){
      key= key + BUCKETSIZE;
      //printf("KEY NOW %d \n", key);

    }
    if(key<0){
      key = key * -1;
    }
  }
  //printf("BEFORE MOD %d \n", key);
  return key % BUCKETSIZE;
}

/*
struct HashTable *table = malloc(sizeof(HashTable));
createHashTable(BUCKETSIZE, table);
struct hashElement* dummyItem;
struct hashElement* item;
*/

/*
 *
 */

 void insert(int thisData, int thisKey){
    //printf("GOLDFISH\n");
    struct hashElement *toInsert = (struct hashElement*) malloc(sizeof(struct hashElement));
    toInsert->data = thisData;
    toInsert->key = thisKey;
    if(hashArray[thisKey]==NULL){
      hashArray[thisKey] = toInsert;
    }else{
      toInsert->next = hashArray[thisKey];
      hashArray[thisKey] = toInsert;
      numCollisions++;
      //printf("~~~~~~~~~~~~~~~~~~~~~~~~`COLLISION: ", numCollisions);
    }

  }

  void search(int thisData, int thisKey){
    if(hashArray[thisKey]!=NULL){
    //  printf("POTENTIAL FIND OF %d\n", thisData);
      struct hashElement* ptr = hashArray[thisKey];
      while(ptr!=NULL){
        if(ptr->data==thisData){
          numSuccessfulSearch++;
        //  printf("----------------------------------------FOUND OF %d\n", thisData);
          break;

        }
        ptr = ptr->next;

      }
    }


  }




int main(int argc, char** argv) {
  FILE *toTest;
  toTest = fopen(argv[1], "r");

  //if does not exist
  if( toTest==NULL)  {
    printf("error");
    return 0;
    //NO FCLOSE OR ELSE IT WILL SEG FAULT  int numNodes = 0;

  }

  //if blank
  if (toTest) {
    fseek (toTest, 0, SEEK_END);
    int size = ftell(toTest);

    if (0 == size) {
        printf("0\n");
        fclose(toTest);
        return 0;
    }
  }


  fseek(toTest, 0, SEEK_SET);
  //hashArray = (hashElement *) malloc(sizeof(hashElement *) * BUCKETSIZE);
  //struct line* array = malloc(number_of_elements * sizeof(struct line));

  //struct hashElement* hashArray = (struct hashElement*)malloc(BUCKETSIZE * sizeof(struct hashElement*));
  //struct hashElement* hashArray = (struct hashElement*) malloc(BUCKETSIZE * sizeof( struct hashElement));

  //memset(hashArray, 0, sizeof(struct hashElement *) * BUCKETSIZE);

  char operation;
  int number;


  while(fscanf(toTest,"%c\t%d\n",&operation,&number)!=EOF){
    //printf("SOMETHING %d", hashArray[0]);struct hashElement* toInsert

    if(operation == 'i'){

      //printf("INSERTING %d \n", number);
      //create key using Data

      int thisKey = getHash(number);
    //printf("THIS IS HASH: %d\n", thisKey);
      insert(number, thisKey);
    //  printf("DONE INSERTING\n");





    }else{
      //printf("SEARCHING %d \n", number);
      int thisKey = getHash(number);
      search(number, thisKey);



    }

  }


    printf("%d\n", numCollisions);
    printf("%d\n", numSuccessfulSearch);
    int i;

    for(i=0; i< 10000; i++){
      // struct hashElement* ptr = hashArray[i];
      if(hashArray[i]!=NULL){

        struct hashElement* ptr = hashArray[i];
        struct hashElement* toFree = hashArray[i];


         while(ptr!=NULL){
           toFree = ptr;
           ptr = ptr->next;
           free(toFree);

         }



     }

  }

    //free(hashArray);


    fclose(toTest);
    return (0);
}
